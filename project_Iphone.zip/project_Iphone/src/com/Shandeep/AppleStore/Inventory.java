package com.Shandeep.AppleStore;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Inventory {
	Statement stmt;
	ResultSet rs;
	String qry=null;
	IphoneDB db=new IphoneDB();
	Connection con;
	List<Iphone> list=new ArrayList<>();
	public void add(Iphone ip) {
		list.add(ip);
		ip.setId(generateId(ip));
	}
	public Iphone search(String series) {
		for(int i=0;i<list.size();i++) {
			if(series.equals(list.get(i).getSeries())) {
				return list.get(i);
			}
		}
		return null;
	}
	public void update() {
		System.out.println("Successfully Updated");
		
	}

	public void show() {
		//for(Iphone ip: list) {
		//	System.out.println(ip.tostring());
		//}
		
		try {
			con=db.getDBConnection();
			stmt=con.createStatement();
			rs=stmt.executeQuery("select * from iphone");
			while(rs.next())
				System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4));
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void remove(String series) {
		for(int i=0;i<list.size();i++) {
			if(series.equals(list.get(i).getSeries())) {
				list.remove(i);
			}
		}
	}
	public String generateId(Iphone ip) {
		String series=ip.getSeries();
		String color=ip.getColor();
		String SeriesId = null;
		String colorId = null;
		String ID;
		if(series.length()>=3) {
			SeriesId= series.substring(series.length()-3);
		}
		if(color.length()>=2) {
			colorId= color.substring(color.length()-2);
		}
		ID=SeriesId+colorId;
		return ID;
	}
	public void pricesort() {
		System.out.println("The Sort of Price");
		Collections.sort(list,new Psort());
	}
	public void colorsort() {
		System.out.println("The Sort of Color");
		Collections.sort(list);
	}
	public void seriessort() {
		System.out.println("The Sort of Series");
		Collections.sort(list,new Ssort());
	}
}
